using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.AspNetCore.Mvc;

using BBS.Application.Interfaces;
using BBS.Application.ViewModels;


namespace BBS.Api.Controllers
{
    [RemoteService]
    [Route("api/[controller]/")]
    public class BallotController : AbpController
    {
        private readonly IBallotAppService _ballotAppService;
        public BallotController(IBallotAppService ballotAppService)
        {
            _ballotAppService = BallotAppService;
        }

        [HttpPost]
        public Task<BallotDto> CreateOrUpdate(CreateOrUpdateBallotDto input)
        {
            return _ballotAppService.CreateOrUpdate(input);
        }

        [HttpPost]
        [Route("delete")]
        public Task Delete(List<Guid> ids)
        {
            return _ballotAppService.Delete(ids);
        }

        [HttpGet]
        [Route("{id}")]
        public Task<BallotDto> Get(Guid id)
        {
            return _ballotAppService.Get(id);
        }

        [HttpGet]
        public Task<PagedResultDto<BallotDto>> GetAll(GetBallotInputDto input)
        {
            return _ballotAppService.GetAll(input);
        }
    }
}