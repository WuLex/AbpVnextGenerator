using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.AspNetCore.Mvc;

using BBS.Application.Interfaces;
using BBS.Application.ViewModels;


namespace BBS.Api.Controllers
{
    [RemoteService]
    [Route("api/[controller]/")]
    public class SubjectController : AbpController
    {
        private readonly ISubjectAppService _subjectAppService;
        public SubjectController(ISubjectAppService subjectAppService)
        {
            _subjectAppService = SubjectAppService;
        }

        [HttpPost]
        public Task<SubjectDto> CreateOrUpdate(CreateOrUpdateSubjectDto input)
        {
            return _subjectAppService.CreateOrUpdate(input);
        }

        [HttpPost]
        [Route("delete")]
        public Task Delete(List<Guid> ids)
        {
            return _subjectAppService.Delete(ids);
        }

        [HttpGet]
        [Route("{id}")]
        public Task<SubjectDto> Get(Guid id)
        {
            return _subjectAppService.Get(id);
        }

        [HttpGet]
        public Task<PagedResultDto<SubjectDto>> GetAll(GetSubjectInputDto input)
        {
            return _subjectAppService.GetAll(input);
        }
    }
}