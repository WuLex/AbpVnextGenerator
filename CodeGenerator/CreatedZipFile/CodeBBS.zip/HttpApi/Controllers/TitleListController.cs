using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.AspNetCore.Mvc;

using BBS.Application.Interfaces;
using BBS.Application.ViewModels;


namespace BBS.Api.Controllers
{
    [RemoteService]
    [Route("api/[controller]/")]
    public class TitlelistController : AbpController
    {
        private readonly ITitlelistAppService _titlelistAppService;
        public TitlelistController(ITitlelistAppService titlelistAppService)
        {
            _titlelistAppService = TitlelistAppService;
        }

        [HttpPost]
        public Task<TitlelistDto> CreateOrUpdate(CreateOrUpdateTitlelistDto input)
        {
            return _titlelistAppService.CreateOrUpdate(input);
        }

        [HttpPost]
        [Route("delete")]
        public Task Delete(List<Guid> ids)
        {
            return _titlelistAppService.Delete(ids);
        }

        [HttpGet]
        [Route("{id}")]
        public Task<TitlelistDto> Get(Guid id)
        {
            return _titlelistAppService.Get(id);
        }

        [HttpGet]
        public Task<PagedResultDto<TitlelistDto>> GetAll(GetTitlelistInputDto input)
        {
            return _titlelistAppService.GetAll(input);
        }
    }
}