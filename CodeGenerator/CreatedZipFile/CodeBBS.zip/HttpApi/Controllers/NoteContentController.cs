using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.AspNetCore.Mvc;

using BBS.Application.Interfaces;
using BBS.Application.ViewModels;


namespace BBS.Api.Controllers
{
    [RemoteService]
    [Route("api/[controller]/")]
    public class NotecontentController : AbpController
    {
        private readonly INotecontentAppService _notecontentAppService;
        public NotecontentController(INotecontentAppService notecontentAppService)
        {
            _notecontentAppService = NotecontentAppService;
        }

        [HttpPost]
        public Task<NotecontentDto> CreateOrUpdate(CreateOrUpdateNotecontentDto input)
        {
            return _notecontentAppService.CreateOrUpdate(input);
        }

        [HttpPost]
        [Route("delete")]
        public Task Delete(List<Guid> ids)
        {
            return _notecontentAppService.Delete(ids);
        }

        [HttpGet]
        [Route("{id}")]
        public Task<NotecontentDto> Get(Guid id)
        {
            return _notecontentAppService.Get(id);
        }

        [HttpGet]
        public Task<PagedResultDto<NotecontentDto>> GetAll(GetNotecontentInputDto input)
        {
            return _notecontentAppService.GetAll(input);
        }
    }
}