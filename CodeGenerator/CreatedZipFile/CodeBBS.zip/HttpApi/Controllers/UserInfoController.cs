using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.AspNetCore.Mvc;

using BBS.Application.Interfaces;
using BBS.Application.ViewModels;


namespace BBS.Api.Controllers
{
    [RemoteService]
    [Route("api/[controller]/")]
    public class UserinfoController : AbpController
    {
        private readonly IUserinfoAppService _userinfoAppService;
        public UserinfoController(IUserinfoAppService userinfoAppService)
        {
            _userinfoAppService = UserinfoAppService;
        }

        [HttpPost]
        public Task<UserinfoDto> CreateOrUpdate(CreateOrUpdateUserinfoDto input)
        {
            return _userinfoAppService.CreateOrUpdate(input);
        }

        [HttpPost]
        [Route("delete")]
        public Task Delete(List<Guid> ids)
        {
            return _userinfoAppService.Delete(ids);
        }

        [HttpGet]
        [Route("{id}")]
        public Task<UserinfoDto> Get(Guid id)
        {
            return _userinfoAppService.Get(id);
        }

        [HttpGet]
        public Task<PagedResultDto<UserinfoDto>> GetAll(GetUserinfoInputDto input)
        {
            return _userinfoAppService.GetAll(input);
        }
    }
}