using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

using BBS.Application.Interfaces.Common;
using BBS.Application.ViewModels;

namespace BBS.Application.Interfaces
{
    public interface ITitlelistAppService : IApplicationService
    {
        Task<TitlelistDto> Get(Guid id);
        Task<PagedResultDto<TitlelistDto>> GetAll(GetTitlelistInputDto input);
        Task<TitlelistDto> CreateOrUpdate(CreateOrUpdateTitlelistDto input);
        Task Delete(List<Guid> ids);
    }
}
