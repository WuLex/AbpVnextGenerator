using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

using BBS.Application.Interfaces.Common;
using BBS.Application.ViewModels;

namespace BBS.Application.Interfaces
{
    public interface INotecontentAppService : IApplicationService
    {
        Task<NotecontentDto> Get(Guid id);
        Task<PagedResultDto<NotecontentDto>> GetAll(GetNotecontentInputDto input);
        Task<NotecontentDto> CreateOrUpdate(CreateOrUpdateNotecontentDto input);
        Task Delete(List<Guid> ids);
    }
}
