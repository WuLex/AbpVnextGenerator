using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

using BBS.Application.Interfaces.Common;
using BBS.Application.ViewModels;

namespace BBS.Application.Interfaces
{
    public interface IUserinfoAppService : IApplicationService
    {
        Task<UserinfoDto> Get(Guid id);
        Task<PagedResultDto<UserinfoDto>> GetAll(GetUserinfoInputDto input);
        Task<UserinfoDto> CreateOrUpdate(CreateOrUpdateUserinfoDto input);
        Task Delete(List<Guid> ids);
    }
}
