using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

using BBS.Application.Interfaces.Common;
using BBS.Application.ViewModels;

namespace BBS.Application.Interfaces
{
    public interface IBallotAppService : IApplicationService
    {
        Task<BallotDto> Get(Guid id);
        Task<PagedResultDto<BallotDto>> GetAll(GetBallotInputDto input);
        Task<BallotDto> CreateOrUpdate(CreateOrUpdateBallotDto input);
        Task Delete(List<Guid> ids);
    }
}
