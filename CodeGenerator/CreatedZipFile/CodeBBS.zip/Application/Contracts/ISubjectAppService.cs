using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

using BBS.Application.Interfaces.Common;
using BBS.Application.ViewModels;

namespace BBS.Application.Interfaces
{
    public interface ISubjectAppService : IApplicationService
    {
        Task<SubjectDto> Get(Guid id);
        Task<PagedResultDto<SubjectDto>> GetAll(GetSubjectInputDto input);
        Task<SubjectDto> CreateOrUpdate(CreateOrUpdateSubjectDto input);
        Task Delete(List<Guid> ids);
    }
}
