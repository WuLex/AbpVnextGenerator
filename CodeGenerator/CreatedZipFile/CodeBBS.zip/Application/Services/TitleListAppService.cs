using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using AutoMapper;

using BBS.Application.Interfaces;
using BBS.Application.Services.Common;
using BBS.Application.ViewModels;
using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Service;





namespace BBS.Application.Services
{
    public class TitlelistAppService : ApplicationService,ITitlelistAppService
    {
        
        private readonly IRepository<Titlelist, Guid> _titlelistRepository;

        public TitlelistAppService(
            IRepository<Titlelist, Guid> titlelistRepository
            )
        {
            _titlelistRepository = titlelistRepository;
        }
        #region 增删改查基础方法

        public async Task<TitlelistDto> Get(Guid id)
        {
            var data = await _titlelistRepository.GetAsync(id);
            var dto = ObjectMapper.Map<Titlelist, TitlelistDto>(data);
            return dto;
        }

        public async Task<PagedResultDto<TitlelistDto>> GetAll(GetTitlelistInputDto input)
        {
            var query = (await _titlelistRepository.GetQueryableAsync()).WhereIf(!string.IsNullOrWhiteSpace(input.Filter), a => a.Name.Contains(input.Filter));

            var totalCount = await query.CountAsync();
            var items = await query.OrderBy(input.Sorting ?? "Id")
                        .ToListAsync();

            var dto = ObjectMapper.Map<List<Titlelist>, List<TitlelistDto>>(items);
            return new PagedResultDto<TitlelistDto>(totalCount, dto);
        }

        public async Task<TitlelistDto> CreateOrUpdate(CreateOrUpdateTitlelistDto input)
        {
            Titlelist result = null;
            if (!input.Id.HasValue)
            {
                input.Id = GuidGenerator.Create();
                result = await _titlelistRepository.InsertAsync(ObjectMapper.Map<CreateOrUpdateTitlelistDto, Titlelist>(input));
            }
            else
            {
                var data = await _titlelistRepository.GetAsync(input.Id.Value);
                result = await _titlelistRepository.UpdateAsync(ObjectMapper.Map(input, data));
            }
            return ObjectMapper.Map<Titlelist, TitlelistDto>(result);
        }

        public async Task Delete(List<Guid> ids)
        {
            foreach (var item in ids)
            {
                await _titlelistRepository.DeleteAsync(item);
            }

        }

     
        #endregion

    }
}