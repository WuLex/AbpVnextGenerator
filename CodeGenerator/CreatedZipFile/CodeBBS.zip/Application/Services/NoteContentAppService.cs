using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using AutoMapper;

using BBS.Application.Interfaces;
using BBS.Application.Services.Common;
using BBS.Application.ViewModels;
using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Service;





namespace BBS.Application.Services
{
    public class NotecontentAppService : ApplicationService,INotecontentAppService
    {
        
        private readonly IRepository<Notecontent, Guid> _notecontentRepository;

        public NotecontentAppService(
            IRepository<Notecontent, Guid> notecontentRepository
            )
        {
            _notecontentRepository = notecontentRepository;
        }
        #region 增删改查基础方法

        public async Task<NotecontentDto> Get(Guid id)
        {
            var data = await _notecontentRepository.GetAsync(id);
            var dto = ObjectMapper.Map<Notecontent, NotecontentDto>(data);
            return dto;
        }

        public async Task<PagedResultDto<NotecontentDto>> GetAll(GetNotecontentInputDto input)
        {
            var query = (await _notecontentRepository.GetQueryableAsync()).WhereIf(!string.IsNullOrWhiteSpace(input.Filter), a => a.Name.Contains(input.Filter));

            var totalCount = await query.CountAsync();
            var items = await query.OrderBy(input.Sorting ?? "Id")
                        .ToListAsync();

            var dto = ObjectMapper.Map<List<Notecontent>, List<NotecontentDto>>(items);
            return new PagedResultDto<NotecontentDto>(totalCount, dto);
        }

        public async Task<NotecontentDto> CreateOrUpdate(CreateOrUpdateNotecontentDto input)
        {
            Notecontent result = null;
            if (!input.Id.HasValue)
            {
                input.Id = GuidGenerator.Create();
                result = await _notecontentRepository.InsertAsync(ObjectMapper.Map<CreateOrUpdateNotecontentDto, Notecontent>(input));
            }
            else
            {
                var data = await _notecontentRepository.GetAsync(input.Id.Value);
                result = await _notecontentRepository.UpdateAsync(ObjectMapper.Map(input, data));
            }
            return ObjectMapper.Map<Notecontent, NotecontentDto>(result);
        }

        public async Task Delete(List<Guid> ids)
        {
            foreach (var item in ids)
            {
                await _notecontentRepository.DeleteAsync(item);
            }

        }

     
        #endregion

    }
}