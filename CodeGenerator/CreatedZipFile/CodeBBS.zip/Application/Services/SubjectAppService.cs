using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using AutoMapper;

using BBS.Application.Interfaces;
using BBS.Application.Services.Common;
using BBS.Application.ViewModels;
using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Service;





namespace BBS.Application.Services
{
    public class SubjectAppService : ApplicationService,ISubjectAppService
    {
        
        private readonly IRepository<Subject, Guid> _subjectRepository;

        public SubjectAppService(
            IRepository<Subject, Guid> subjectRepository
            )
        {
            _subjectRepository = subjectRepository;
        }
        #region 增删改查基础方法

        public async Task<SubjectDto> Get(Guid id)
        {
            var data = await _subjectRepository.GetAsync(id);
            var dto = ObjectMapper.Map<Subject, SubjectDto>(data);
            return dto;
        }

        public async Task<PagedResultDto<SubjectDto>> GetAll(GetSubjectInputDto input)
        {
            var query = (await _subjectRepository.GetQueryableAsync()).WhereIf(!string.IsNullOrWhiteSpace(input.Filter), a => a.Name.Contains(input.Filter));

            var totalCount = await query.CountAsync();
            var items = await query.OrderBy(input.Sorting ?? "Id")
                        .ToListAsync();

            var dto = ObjectMapper.Map<List<Subject>, List<SubjectDto>>(items);
            return new PagedResultDto<SubjectDto>(totalCount, dto);
        }

        public async Task<SubjectDto> CreateOrUpdate(CreateOrUpdateSubjectDto input)
        {
            Subject result = null;
            if (!input.Id.HasValue)
            {
                input.Id = GuidGenerator.Create();
                result = await _subjectRepository.InsertAsync(ObjectMapper.Map<CreateOrUpdateSubjectDto, Subject>(input));
            }
            else
            {
                var data = await _subjectRepository.GetAsync(input.Id.Value);
                result = await _subjectRepository.UpdateAsync(ObjectMapper.Map(input, data));
            }
            return ObjectMapper.Map<Subject, SubjectDto>(result);
        }

        public async Task Delete(List<Guid> ids)
        {
            foreach (var item in ids)
            {
                await _subjectRepository.DeleteAsync(item);
            }

        }

     
        #endregion

    }
}