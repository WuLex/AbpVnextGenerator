using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using AutoMapper;

using BBS.Application.Interfaces;
using BBS.Application.Services.Common;
using BBS.Application.ViewModels;
using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Service;





namespace BBS.Application.Services
{
    public class BallotAppService : ApplicationService,IBallotAppService
    {
        
        private readonly IRepository<Ballot, Guid> _ballotRepository;

        public BallotAppService(
            IRepository<Ballot, Guid> ballotRepository
            )
        {
            _ballotRepository = ballotRepository;
        }
        #region 增删改查基础方法

        public async Task<BallotDto> Get(Guid id)
        {
            var data = await _ballotRepository.GetAsync(id);
            var dto = ObjectMapper.Map<Ballot, BallotDto>(data);
            return dto;
        }

        public async Task<PagedResultDto<BallotDto>> GetAll(GetBallotInputDto input)
        {
            var query = (await _ballotRepository.GetQueryableAsync()).WhereIf(!string.IsNullOrWhiteSpace(input.Filter), a => a.Name.Contains(input.Filter));

            var totalCount = await query.CountAsync();
            var items = await query.OrderBy(input.Sorting ?? "Id")
                        .ToListAsync();

            var dto = ObjectMapper.Map<List<Ballot>, List<BallotDto>>(items);
            return new PagedResultDto<BallotDto>(totalCount, dto);
        }

        public async Task<BallotDto> CreateOrUpdate(CreateOrUpdateBallotDto input)
        {
            Ballot result = null;
            if (!input.Id.HasValue)
            {
                input.Id = GuidGenerator.Create();
                result = await _ballotRepository.InsertAsync(ObjectMapper.Map<CreateOrUpdateBallotDto, Ballot>(input));
            }
            else
            {
                var data = await _ballotRepository.GetAsync(input.Id.Value);
                result = await _ballotRepository.UpdateAsync(ObjectMapper.Map(input, data));
            }
            return ObjectMapper.Map<Ballot, BallotDto>(result);
        }

        public async Task Delete(List<Guid> ids)
        {
            foreach (var item in ids)
            {
                await _ballotRepository.DeleteAsync(item);
            }

        }

     
        #endregion

    }
}