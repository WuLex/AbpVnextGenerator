using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using AutoMapper;

using BBS.Application.Interfaces;
using BBS.Application.Services.Common;
using BBS.Application.ViewModels;
using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Service;





namespace BBS.Application.Services
{
    public class UserinfoAppService : ApplicationService,IUserinfoAppService
    {
        
        private readonly IRepository<Userinfo, Guid> _userinfoRepository;

        public UserinfoAppService(
            IRepository<Userinfo, Guid> userinfoRepository
            )
        {
            _userinfoRepository = userinfoRepository;
        }
        #region 增删改查基础方法

        public async Task<UserinfoDto> Get(Guid id)
        {
            var data = await _userinfoRepository.GetAsync(id);
            var dto = ObjectMapper.Map<Userinfo, UserinfoDto>(data);
            return dto;
        }

        public async Task<PagedResultDto<UserinfoDto>> GetAll(GetUserinfoInputDto input)
        {
            var query = (await _userinfoRepository.GetQueryableAsync()).WhereIf(!string.IsNullOrWhiteSpace(input.Filter), a => a.Name.Contains(input.Filter));

            var totalCount = await query.CountAsync();
            var items = await query.OrderBy(input.Sorting ?? "Id")
                        .ToListAsync();

            var dto = ObjectMapper.Map<List<Userinfo>, List<UserinfoDto>>(items);
            return new PagedResultDto<UserinfoDto>(totalCount, dto);
        }

        public async Task<UserinfoDto> CreateOrUpdate(CreateOrUpdateUserinfoDto input)
        {
            Userinfo result = null;
            if (!input.Id.HasValue)
            {
                input.Id = GuidGenerator.Create();
                result = await _userinfoRepository.InsertAsync(ObjectMapper.Map<CreateOrUpdateUserinfoDto, Userinfo>(input));
            }
            else
            {
                var data = await _userinfoRepository.GetAsync(input.Id.Value);
                result = await _userinfoRepository.UpdateAsync(ObjectMapper.Map(input, data));
            }
            return ObjectMapper.Map<Userinfo, UserinfoDto>(result);
        }

        public async Task Delete(List<Guid> ids)
        {
            foreach (var item in ids)
            {
                await _userinfoRepository.DeleteAsync(item);
            }

        }

     
        #endregion

    }
}